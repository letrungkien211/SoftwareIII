#ifndef PC104CTRL_H_INCLUDED_
#define PC104CTRL_H_INCLUDED_

#include "pc104driver.h"

int pc104_open();
void pc104_close(int fd);

#endif
