#ifndef PC104CTRL_THREAD_H_INCLUDED_
#define PC104CTRL_THREAD_H_INCLUDED_

#include "pc104driver.h"

int pc104_open_mt();
int pc104_close_mt();
int pc104_ioctl_mt(int request, void *value);

#endif
